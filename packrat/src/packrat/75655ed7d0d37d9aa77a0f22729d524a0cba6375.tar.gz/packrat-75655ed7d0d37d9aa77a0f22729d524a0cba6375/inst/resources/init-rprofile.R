#### -- Packrat Autoloader (version 0.3.0.99) -- ####
source("packrat/init.R")
#### -- End Packrat Autoloader -- ####
