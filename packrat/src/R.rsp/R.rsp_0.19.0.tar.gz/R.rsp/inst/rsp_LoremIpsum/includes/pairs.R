# From the 'graphics' package
pairs(iris)
