
make_addition = function(a, b) {
  c=a+b
  plot(c)
  return(c)
}
