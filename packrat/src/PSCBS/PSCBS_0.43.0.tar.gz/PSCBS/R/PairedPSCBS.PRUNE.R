setMethodS3("seqOfSegmentsByDP", "PairedPSCBS", function(fit, by=c("CT", "rho"), ...) {
  NextMethod("seqOfSegmentsByDP", by=by);
})


############################################################################
# HISTORY:
# 2012-09-13
# o Added seqOfSegmentsByDP() for PairedPSCBS.
# o Created.
############################################################################
