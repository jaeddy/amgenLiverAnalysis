library("BatchJobs");

reg <- makeRegistry("aroma_affymetrix");
print(reg);


