#! /usr/bin/env sh

# Addons
qRscript testScripts/launch.R --group=addons --pattern=Mapping250K_Nsp$
qRscript testScripts/launch.R --group=addons --pattern=Mapping50K_Hind240
# qRscript testScripts/launch.R --group=addons --pattern=Mapping250K_Nsp,Sty

