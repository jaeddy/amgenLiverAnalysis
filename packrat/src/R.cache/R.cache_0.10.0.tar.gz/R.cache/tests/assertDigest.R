R.cache:::.assertDigest()

library("R.cache")
R.cache:::.assertDigest()
