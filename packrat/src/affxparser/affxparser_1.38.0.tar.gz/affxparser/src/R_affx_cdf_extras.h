#if !defined(R_AFFX_CDF_EXTRAS_H)
#define R_AFFX_CDF_EXTRAS_H
extern "C" {
    /* utility functions that can be used elsewhere in the code */
int R_affx_pt_base_is_pm(char p_base, char t_base);

}
#endif
