setConstructorS3("FileShortMatrix", function(...) {
  extend(FileMatrix(..., bytesPerCell=2, storageMode="integer"), "FileShortMatrix")
})


############################################################################
# HISTORY:
# 2006-01-22
# o Created.
############################################################################ 
