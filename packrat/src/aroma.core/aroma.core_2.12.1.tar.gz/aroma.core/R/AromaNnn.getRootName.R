setMethodS3("getRootName", "AromaTabularBinarySet", function(this, ..., tags="*") {
  getParentName(this, depth=2, tags=tags, ...);
}, protected=TRUE)

setMethodS3("getRootName", "AromaTabularBinaryFile", function(this, ..., tags="*") {
  getParentName(this, depth=2, tags=tags, ...);
}, protected=TRUE)


############################################################################
# HISTORY:
# 2010-05-12
# o Created.
############################################################################
