library("R.devices")

devAll <- R.devices:::devAll

print(devAll())
