# Added '...' to some base functions. These will later be
# turned into default functions by setMethodS3().


############################################################################
# HISTORY:
# 2011-11-05
# o Created to please R CMD check.
############################################################################
